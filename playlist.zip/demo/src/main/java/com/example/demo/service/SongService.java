package com.example.demo.service;

import com.example.demo.models.Song;
import com.example.demo.repository.SongRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SongService {
    @Autowired
    public SongRepository songRepository;
    private Long id;

    public List<Song> getAllSongs()
    {
        return songRepository.findAll();

    }
    public Song getSongById(Long id)
    {
        return songRepository.getById(id);

    }
    public Song updateSong(Song update)
    {
        Song songDataBase=songRepository.getById(id);
        if (songDataBase!=null){
            return songRepository.save(update);
        }
        return null;
    }
    public String deleteSong(Long id)
    {
        Song songDataBase=songRepository.getById(id);
        if (songDataBase!=null){
            songRepository.delete(songDataBase);
            return "Se elimino el registro con Exito.";
        }
        return "No Existe el ID dentro de la base de datos.";

    }

    public Song saveSong(Song saveForSave)
    {
        return songRepository.save(saveForSave);

    }
}
