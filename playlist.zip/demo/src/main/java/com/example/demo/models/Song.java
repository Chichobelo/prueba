package com.example.demo.models;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
public class Song {

    @Id
    @Column(name = "idsong")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Getter
    @Setter
    private  long idSong;



    @Column(name="artist_name")
    @Getter
    @Setter
    private String artist;


    @Column(name = "title")
    @Getter
    @Setter
    private String title;



    @Column(name = "Album")
    @Getter
    @Setter

    private String album;



    @Column(name = "year")
    @Getter
    @Setter

    private String year;


}
