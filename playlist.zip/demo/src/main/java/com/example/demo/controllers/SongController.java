package com.example.demo.controllers;


import com.example.demo.models.Song;
import com.example.demo.service.SongService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/api/song", produces = MediaType.APPLICATION_JSON_VALUE)
@CrossOrigin(origins = "*")
public class SongController {


    @Autowired
    private SongService songService;



    @GetMapping(path = "/all", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<Song> getAllSong(){
        return songService.getAllSongs();

    }

    @GetMapping(path = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public  Song getSongById(@PathVariable(name="id") Long id){
        return songService.getSongById(id);


    }

    @PostMapping( consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Song saveSong(@RequestBody Song song){
        return songService.saveSong(song);

    }


    @PutMapping ( path = "/{id}",consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Song updateSong(@PathVariable(name= "id") Long id,@RequestBody Song update){
        return songService.updateSong(update);

    }

    @DeleteMapping (path = "/{id}",consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public String deleSong(@PathVariable(name= "id") Long id){
        return songService.deleteSong(id);
    }
}
