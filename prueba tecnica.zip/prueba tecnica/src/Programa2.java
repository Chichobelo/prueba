import java.util.Scanner;

public class Programa2 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		System.out.print("Ingrese el nombre del equipo: ");
		String nombreDelEquipo = scanner.nextLine();
		System.out.print("Ingrese el estadio del equipo: ");
		String estadioDelEquipo = scanner.nextLine();
		System.out.print("Ingrese la cantidad de títulos: ");
		int numeroDeTitulos = scanner.nextInt();
		scanner.nextLine();

		EquipoDeFutbol equipo = new EquipoDeFutbol(nombreDelEquipo, estadioDelEquipo, numeroDeTitulos);
		while (true) {
			System.out.println("\nSeleccione una opción:");
			System.out.println("1. Agregar jugador titular");
			System.out.println("2. Agregar jugador suplente");
			System.out.println("3. Generar reporte básico");
			System.out.println("4. Generar reporte detallado");
			System.out.println("5. Salir");

			int opcion = scanner.nextInt();
			scanner.nextLine();

			switch (opcion) {
				case 1:
					System.out.print("Ingrese el nombre del jugador titular: ");
					String nombreTitular = scanner.nextLine();
					System.out.print("Ingrese la posición del jugador titular: ");
					String posicionTitular = scanner.nextLine();
					Jugador titular = new Jugador(nombreTitular, posicionTitular);
					equipo.agregarJugadorTitular(titular);
					break;
				case 2:
					System.out.print("Ingrese el nombre del jugador suplente: ");
					String nombreSuplente = scanner.nextLine();
					System.out.print("Ingrese la posición del jugador suplente: ");
					String posicionSuplente = scanner.nextLine();
					Jugador suplente = new Jugador(nombreSuplente, posicionSuplente);
					equipo.agregarJugadorSuplente(suplente);
					break;
				case 3:
					equipo.generarReporteBasico();
					break;
				case 4:
					equipo.generarReporteDetallado();
					break;
				case 5:
					System.exit(0);
				default:
					System.out.println("Opción no válida .Por favor, Seleccione una opción válida.");
			}
		}
	}
}



