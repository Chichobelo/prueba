import java.util.ArrayList;
import java.util.List;

class EquipoDeFutbol {
	private String nombreDelEquipo; // Nombre del equipo de fútbol
	private String estadioDelEquipo; // Estadio donde juega el equipo
	private int numeroDeTitulos; // Cantidad de títulos ganados por el equipo
	private List<Jugador> jugadoresTitulares; // Lista de jugadores titulares
	private List<Jugador> jugadoresSuplentes; // Lista de jugadores suplentes

	public EquipoDeFutbol(String nombreDelEquipo, String estadioDelEquipo, int numeroDeTitulos) {
		this.nombreDelEquipo = nombreDelEquipo;
		this.estadioDelEquipo = estadioDelEquipo;
		this.numeroDeTitulos = numeroDeTitulos;
		this.jugadoresTitulares = new ArrayList<>();
		this.jugadoresSuplentes = new ArrayList<>();
	}

	public void agregarJugadorTitular(Jugador jugador) {
		jugadoresTitulares.add(jugador);
	}

	public void agregarJugadorSuplente(Jugador jugador) {
		jugadoresSuplentes.add(jugador);
	}

	public void generarReporteBasico() {
		System.out.println("Reporte Básico:");
		System.out.println("Nombre del equipo: " + nombreDelEquipo);
		System.out.println("Títulos ganados: " + numeroDeTitulos);
		System.out.println("Cantidad total de jugadores: " + (jugadoresTitulares.size() + jugadoresSuplentes.size()));
	}

	public void generarReporteDetallado() {
		System.out.println("Reporte Detallado:");
		System.out.println("Nombre del equipo: " + nombreDelEquipo);
		System.out.println("Estadio: " + estadioDelEquipo);
		System.out.println("Títulos ganados: " + numeroDeTitulos);

		System.out.println("Jugadores titulares:");
		for (Jugador titular : jugadoresTitulares) {
			System.out.println("Nombre: " + titular.getNombre() + ", Posición: " + titular.getPosicion());
		}

		System.out.println("Jugadores suplentes:");
		for (Jugador suplente : jugadoresSuplentes) {
			System.out.println("Nombre: " + suplente.getNombre() + ", Posición: " + suplente.getPosicion());
		}
	}
}


