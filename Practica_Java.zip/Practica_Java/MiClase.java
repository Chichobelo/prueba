
// Se utilizara cuando el usuario ingresa un tipo de dato diferente al esperado
import java.util.InputMismatchException;
import java.util.Scanner;

public class MiClase {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int numero = 0; // Declaramos la primera variable para almacenar el numero
        boolean esEntradaValida = false;
    
         // Se utiliza un bucle do-while para repetir la solicitud de entrada hasta que la entrada sea valida   
        do {
            System.out.print("Ingrese un número entero positivo (entre 1 y 100): ");
            // Se utiliza un bloque try-catch para manejar las excepciones.
            try {
                numero = scanner.nextInt();
                if (numero < 1 || numero > 100) {
                    System.out.println("Error. El número debe estar en el rango de 1 a 100.");
                } else {
                    esEntradaValida = true; // Se establece en true para salir del bucle 
                }
            } catch (InputMismatchException e) {
                System.out.println("Error. Debe ingresar un número entero.");
                scanner.next();  // Descartar la entrada incorrecta
            }
        } while (!esEntradaValida);

        // Evaluamos el numero que fue ingresado y se determina si es "Quipux" o "No Quipux" con un switch y if-else
        if (numero % 2 == 0) {
            if (numero <= 5 || numero > 20) {
                System.out.println("No Quipux");
            } else {
                System.out.println("Quipux");
            }
        } else {
            System.out.println("Quipux");
        }

        scanner.close(); // Cerramos el scanner para evitar fuga de memoria 
    }
}




